/**
  * Copyright 2020 bejson.com 
  */
package com.movie.moviecomment.bean.movieDetail;

/**
 * Auto-generated: 2020-07-05 17:5:12
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Distributor {

    private String uri;
    public void setUri(String uri) {
         this.uri = uri;
     }
     public String getUri() {
         return uri;
     }

}