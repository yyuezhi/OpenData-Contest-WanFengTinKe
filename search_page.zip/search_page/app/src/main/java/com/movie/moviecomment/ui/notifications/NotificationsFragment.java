package com.movie.moviecomment.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;

import com.movie.moviecomment.R;
import com.movie.moviecomment.ui.home.HomeFragment;

public class NotificationsFragment extends Fragment {


    private static NotificationsFragment fragment;
    public static NotificationsFragment newInstance() {

        Bundle args = new Bundle();
        if (fragment==null){
            fragment = new NotificationsFragment();
        }

        fragment.setArguments(args);
        return fragment;
    }
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_notifications, container, false);
        final TextView textView = root.findViewById(R.id.text_notifications);

        return root;
    }
}