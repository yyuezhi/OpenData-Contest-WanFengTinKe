package com.movie.moviecomment.bean;

public class Data {

}
