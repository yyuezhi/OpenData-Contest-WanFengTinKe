/**
  * Copyright 2020 bejson.com 
  */
package com.movie.moviecomment.bean;

/**
 * Auto-generated: 2020-07-04 18:31:52
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class ActorList {

    private String pname;
    private String puri;
    public void setPname(String pname) {
         this.pname = pname;
     }
     public String getPname() {
         return pname;
     }

    public void setPuri(String puri) {
         this.puri = puri;
     }
     public String getPuri() {
         return puri;
     }

}