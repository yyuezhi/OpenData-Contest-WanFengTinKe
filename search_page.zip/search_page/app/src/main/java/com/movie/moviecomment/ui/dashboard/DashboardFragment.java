package com.movie.moviecomment.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;

import com.movie.moviecomment.R;
import com.movie.moviecomment.ui.notifications.NotificationsFragment;

public class DashboardFragment extends Fragment {

    private static DashboardFragment fragment;
    public static DashboardFragment newInstance() {

        Bundle args = new Bundle();
        if (fragment==null){
            fragment = new DashboardFragment();
        }

        fragment.setArguments(args);
        return fragment;
    }
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        final TextView textView = root.findViewById(R.id.text_dashboard);

        return root;
    }
}