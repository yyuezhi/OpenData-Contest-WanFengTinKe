package com.example.film_page;

public class MainModel {
    Integer actorPic;
    String actorName;

    public MainModel(Integer pic,String name){
        this.actorPic = pic;
        this.actorName = name;
    }

    public Integer getActor_pic(){
        return actorPic;
    }

    public String getActor_name(){
        return actorName;
    }
}
