package com.example.film_page;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //initialize variable
    RecyclerView recyclerView;
    ArrayList<MainModel> mainModels;
    MainAdapter mainAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign variable
        recyclerView = findViewById(R.id.recycler_view);

        //Create integer array
        Integer[] actorPic = {R.drawable.actor1, R.drawable.actor2, R.drawable.actor3, R.drawable.actor4};

        //Create string array
        String[] actorName = {"费·雯丽", "克拉克·盖博", "莱斯利·霍华德", "哈蒂·麦克丹尼尔"};

        //Initialize arraylist
        mainModels = new ArrayList<>();
        for (int i = 0; i < actorPic.length; i++){
            MainModel model = new MainModel(actorPic[i], actorName[i]);
            mainModels.add(model);
        }

        //Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        //Initialiize MainAdapter
        mainAdapter = new MainAdapter(MainActivity.this, mainModels);
        //Set MainAdapter to RecyclerView
        recyclerView.setAdapter(mainAdapter);
    }
}


























