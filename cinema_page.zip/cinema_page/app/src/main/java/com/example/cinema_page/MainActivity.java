package com.example.cinema_page;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    String URL_CinemaList = "http://data1.library.sh.cn/shnh/dydata/webapi/architecture/getArchitecture?free%20text=%E4%B8%8A%E6%B5%B7%E5%A4%A7%E6%88%8F%E9%99%A2&key=ac55669606af89333c79296def567d4b48059d4b";
    List<ArrayList<String>> listOfCinema;

    //Assign variable
    private TextView cinema_name;
    TextView intro;
    TextView intro_details;
    ImageView cinema_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cinema_name = (TextView)findViewById(R.id.cinema_name);
        intro = (TextView)findViewById(R.id.intro);
        intro_details = (TextView)findViewById(R.id.intro_details);
        cinema_image = (ImageView)findViewById(R.id.cinema_image);
        intro_details.findViewById(R.id.intro_details).setSelected(true);

        listOfCinema = new ArrayList<ArrayList<String>>();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_CinemaList,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray array = jsonObject.getJSONArray("data");

                            for (int i = 0; i<array.length(); i++){
                                JSONObject o = array.getJSONObject(i);
                                ArrayList<String> cinema_details = new ArrayList<String>();
                                cinema_details.add(o.getString("nameT")); //0
                                cinema_details.add(o.getString("nameS")); //1
                                cinema_details.add(o.getString("nameE")); //2
                                cinema_details.add(o.getString("orgName")); //3
                                cinema_details.add(o.getString("des")); //4
                                cinema_details.add(o.getString("bUri")); //5
                                cinema_details.add(o.getString("nameOtherUri")); //6
                                cinema_details.add(o.getString("dramaName")); //7
                                cinema_details.add(o.getString("nameOther")); //8
                                cinema_details.add(o.getString("uri")); //9
                                cinema_details.add(o.getString("movieName")); //10
                                cinema_details.add(o.getString("personList")); //11
                                listOfCinema.add(cinema_details);
                                cinema_name.setText(cinema_details.get(1));
                                intro.setText("简介");
                                intro_details.setText(cinema_details.get(4));

                                String url = cinema_details.get(9);
                                if (!url.equalsIgnoreCase(""))
                                    Picasso.get().load(url).into(cinema_image);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                });
    RequestQueue requestQueue = Volley.newRequestQueue(this);
    requestQueue.add(stringRequest);
    }
}


