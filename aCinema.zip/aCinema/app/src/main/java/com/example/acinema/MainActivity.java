package com.example.acinema;
import com.example.acinema.R;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView nameCHI, nameENG, otherNAME, intros, detail, relatedP, personLIST;
    ProgressDialog progressDialog = new ProgressDialog(this);
    RequestQueue requestQueue;
    ArrayList<String> personName;
    //List<ArrayList<String>> listofcinema;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameCHI = findViewById(R.id.nameS);
        nameENG = findViewById(R.id.nameE);
        otherNAME = findViewById(R.id.otherName);
        intros = findViewById(R.id.intro);
        intros.setText("简介");
        detail = findViewById(R.id.details);
        relatedP = findViewById(R.id.related);
        relatedP.setText("相关人物");
        personLIST = findViewById(R.id.personList);

        requestQueue = Volley.newRequestQueue(this);

        progressDialog.setMessage("加载中...");
        progressDialog.show();

        String url = "http://data1.library.sh.cn/shnh/dydata/webapi/architecture/getArchitecture?free%20text=%E4%B8%8A%E6%B5%B7%E5%A4%A7%E6%88%8F%E9%99%A2&key=ac55669606af89333c79296def567d4b48059d4b";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("data");
                    ArrayList<String> cinemaList = new ArrayList<String>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject cinema = jsonArray.getJSONObject(i);
                        String chinese = cinema.getString("nameS");
                        String english = cinema.getString("nameE");
                        String otherNames = cinema.getString("nameOther");
                        String introDetails = cinema.getString("des");
                        JSONArray personLists = cinema.getJSONArray("personList");
                        for (int j = 0; j < personLists.length(); j++) {
                            JSONObject person = personLists.getJSONObject(j);
                            String puri = person.getString("puri");
                            personName.add(puri+"/n");
                        }
                        String nameList = personName.toString();
                        nameCHI.append(chinese);
                        nameENG.append(english);
                        otherNAME.append(otherNames);
                        detail.append(introDetails);
                        personLIST.append(nameList);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }
}